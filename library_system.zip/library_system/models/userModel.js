const db = require('../config/db');

const User = {
  // 获取用户信息
  getUserById: async (userId) => {
    try {
       console.log(`执行用户查询: ID=${userId}`);
      const [rows] = await db.query(
        `SELECT 
          id, 
          username, 
          is_vip AS isVip, 
          vip_days AS vipDays, 
          credit_score AS creditScore,
          (SELECT COUNT(*) FROM borrow_records WHERE user_id = ?) AS totalBorrowed,
          (SELECT COUNT(*) FROM borrow_records WHERE user_id = ? AND return_date IS NULL) AS currentBorrowed,
          reading_rank AS readingRank
        FROM users
        WHERE id = ?`,
        [userId, userId, userId]
      );
      return rows[0] || null;
    } catch (error) {
      console.error('获取用户信息失败:', error);
      throw error;
    }
  },

  // 获取用户借阅记录
  getBorrowRecords: async (userId, type) => {
    try {
      let query = `
        SELECT 
          br.id, 
          b.title, 
          b.author, 
          b.cover, 
          DATE_FORMAT(br.borrow_date, '%Y-%m-%d') AS borrowDate,
          DATE_FORMAT(br.due_date, '%Y-%m-%d') AS dueDate,
          DATE_FORMAT(br.return_date, '%Y-%m-%d') AS returnDate,
          CASE
            WHEN br.return_date IS NOT NULL AND br.return_date > br.due_date THEN 'overdue-returned'
            WHEN br.return_date IS NOT NULL THEN 'returned'
            WHEN br.due_date < CURDATE() THEN 'overdue'
            ELSE 'borrowed'
          END AS status,
          b.id AS bookId  -- 确保返回 bookId
        FROM borrow_records br
        JOIN books b ON br.book_id = b.id
        WHERE br.user_id = ?
      `;
      
      let params = [userId];

      if (type === 'current') {
        query += " AND br.return_date IS NULL";
      } else if (type === 'overdue') {
        query += " AND br.due_date < CURDATE() AND br.return_date IS NULL";
      } else if (type === 'history') {
        query += " AND br.return_date IS NOT NULL";
      }
      
      query += " ORDER BY br.borrow_date DESC";
      
      const [rows] = await db.query(query, params);
      return rows;
    } catch (error) {
      console.error('获取借阅记录失败:', { userId, type, error: error.message, sql: error.sql });
      throw error;
    }
  }
};

module.exports = User;