const db = require('../config/db');
const Book = require('./bookModel');

const Borrow = {
  // 创建借阅记录
    createBorrowRecord: async (record, connection = db) => {
    try {
      const [result] = await connection.query(
        `INSERT INTO borrow_records 
         (user_id, book_id, borrow_date, due_date, status)
         VALUES (?, ?, ?, ?, ?)`,
        [
          record.userId,
          record.bookId,
          record.borrowDate,
          record.dueDate,
          'borrowed'
        ]
      );
      return result;
    } catch (error) {
      throw error;
    }
  },
    //归还图书
    returnBook: async (recordId, returnDate, connection) => {
        try {
            // 更新归还日期和状态
            const [updateResult] = await connection.query(
            `UPDATE borrow_records 
            SET return_date = ?, status = 'returned'
            WHERE id = ?`,
            [returnDate, recordId]
            );
            
            return updateResult.affectedRows > 0;
        } catch (error) {
            console.error(`归还图书失败: ${error.message}`);
            throw error;
        }
    },
  
  // 根据用户ID获取借阅记录
    getRecordsByUser: async (userId) => {
        try {
        const [rows] = await db.query(
            `SELECT br.id, b.title, b.author, 
                    DATE_FORMAT(br.borrow_date, '%Y-%m-%d') AS borrowDate,
                    DATE_FORMAT(br.due_date, '%Y-%m-%d') AS dueDate,
                    DATE_FORMAT(br.return_date, '%Y-%m-%d') AS returnDate,
                    br.status
            FROM borrow_records br
            JOIN books b ON br.book_id = b.id
            WHERE br.user_id = ?`,
            [userId]
        );
        return rows;
        } catch (error) {
        throw error;
        }
    },
  
    getRecordById: async (recordId, connection = db) => {
        try {
            const [rows] = await connection.query(
            `SELECT * FROM borrow_records WHERE id = ?`,
            [recordId]
            );
            return rows[0] || null;
        } catch (error) {
            throw error;
        }
    },
    updateReturnDate: async (recordId, returnDate) => {
    try {
        const [result] = await db.query(
        `UPDATE borrow_records 
        SET return_date = ?, status = 'returned'
        WHERE id = ?`,
        [returnDate, recordId]
        );
        return result;
    } catch (error) {
        throw error;
    }
    },
    getBookById: async (bookId) => {
    try {
        const [rows] = await db.query(
        `SELECT id, title, author, status 
        FROM books WHERE id = ?`,
        [bookId]
        );
        return rows[0] || null;
    } catch (error) {
        throw error;
    }
    },
    updateBookStatus: async (bookId, status) => {
    try {
        const [result] = await db.query(
        `UPDATE books SET status = ? WHERE id = ?`,
        [status, bookId]
        );
        return result.affectedRows > 0;
    } catch (error) {
        throw error;
    }
    }
};

module.exports = Borrow;