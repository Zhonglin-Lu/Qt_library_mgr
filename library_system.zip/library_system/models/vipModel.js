const db = require('../config/db');

const Vip = {
  // 增加VIP天数并记录充值
  addVipDays: async (userId, packageType, days) => {
    const connection = await db.getConnection();
    try {
      await connection.beginTransaction();
      
      // 更新用户VIP天数
      const [updateResult] = await connection.query(
        `UPDATE users 
         SET vip_days = vip_days + ?, 
             is_vip = 1 
         WHERE id = ?`,
        [days, userId]
      );
      
      // 添加充值记录
      const [insertResult] = await connection.query(
        `INSERT INTO recharge_records (user_id, package_type, days_added)
         VALUES (?, ?, ?)`,
        [userId, packageType, days]
      );
      
      await connection.commit();
      
      return {
        updateSuccess: updateResult.affectedRows > 0,
        recordId: insertResult.insertId
      };
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  },
  
  // 获取用户充值记录
  getRechargeRecords: async (userId) => {
      try {
        const [rows] = await db.query(
          `SELECT id, package_type AS packageType, 
                  days_added AS daysAdded, 
                  DATE_FORMAT(recharge_date, '%Y-%m-%d %H:%i:%s') AS rechargeDate
          FROM recharge_records
          WHERE user_id = ?
          ORDER BY recharge_date DESC`,
          [userId]
        );
        return rows;
      } catch (error) {
        throw error;
      }
    }
};

module.exports = Vip;