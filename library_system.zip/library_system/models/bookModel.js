const db = require('../config/db');
const NodeCache = require('node-cache');
const bookCache = new NodeCache({ stdTTL: 600 }); // 10分钟缓存

const Book = {
  // 获取推荐图书
  getRecommendedBooks: async () => {
    try {
      const [rows] = await db.query(
        `SELECT id, title, author, category, isbn, publisher, 
         publish_date AS publishDate, cover, description, status, rating
         FROM books
         ORDER BY rating DESC
         LIMIT 4`
      );
      return rows;
    } catch (error) {
      throw error;
    }
  },

  // 获取热门图书
  getPopularBooks: async () => {
    try {
      const [rows] = await db.query(
        `SELECT id, title, author, category, isbn, publisher, 
         publish_date AS publishDate, cover, description, status, rating
         FROM books
         ORDER BY borrow_count DESC
         LIMIT 8`
      );
      return rows;
    } catch (error) {
      throw error;
    }
  },

  // 获取最新图书
  getNewBooks: async () => {
    try {
      const [rows] = await db.query(
        `SELECT id, title, author, category, isbn, publisher, 
         publish_date AS publishDate, cover, description, status, rating
         FROM books
         ORDER BY added_date DESC
         LIMIT 4`
      );
      return rows;
    } catch (error) {
      throw error;
    }
  },

  // 搜索图书
  searchBooks: async (query) => {
    try {
      const [rows] = await db.query(
        `SELECT id, title, author, category, isbn, publisher, 
         publish_date AS publishDate, cover, description, status, rating
         FROM books
         WHERE title LIKE ? OR author LIKE ? OR category LIKE ? OR isbn LIKE ?`,
        [`%${query}%`, `%${query}%`, `%${query}%`, `%${query}%`]
      );
      return rows;
    } catch (error) {
      throw error;
    }
  },
  // 获取图书详情
  getBookById: async (bookId, connection = db) => {
    try {
      const [rows] = await connection.query(
        `SELECT id, title, author, status 
         FROM books 
         WHERE id = ?`,
        [bookId]
      );
      return rows[0] || null;
    } catch (error) {
      throw error;
    }
  },
  // 在 bookModel.js 中添加
  getBookDetail: async (bookId) => {
    try {
      const [rows] = await db.query(
        `SELECT id, title, author, category, isbn, publisher, 
        publish_date AS publishDate, cover, description, status, rating
        FROM books 
        WHERE id = ?`,
        [bookId]
      );
      return rows[0] || null;
    } catch (error) {
      throw error;
    }
  },

  //更新图书状态
  updateBookStatus: async (bookId, status, connection = db) => {
    try {
      const [result] = await connection.query(
        `UPDATE books 
        SET status = ? 
        WHERE id = ?`,
        [status, bookId]
      );
      
      return result.affectedRows > 0;
    } catch (error) {
      console.error(`更新图书状态失败: ${error.message}`);
      throw error;
    }
  }
};

module.exports = Book;