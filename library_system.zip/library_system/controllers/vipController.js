const Vip = require('../models/vipModel');
const NodeCache = require('node-cache');
const vipCache = new NodeCache({ stdTTL: 600 }); // 10分钟缓存

// 增加VIP天数
exports.addVipDays = async (req, res) => {
  const { userId } = req.params;
  const { packageType } = req.body;

  // 添加输入验证
  if (!packageType || !['monthly', 'quarterly', 'yearly'].includes(packageType)) {
    return res.status(400).json({ 
      error: 'Invalid package type',
      message: '套餐类型无效，请提供有效的套餐类型（monthly, quarterly, yearly）'
    });
  }

  // 计算天数
  const packageDays = {
    monthly: 30,
    quarterly: 90,
    yearly: 365
  };
  
  const days = packageDays[packageType] || 0;

  try {
    const result = await Vip.addVipDays(userId, packageType, days);
    
    if (!result.updateSuccess) {
      return res.status(404).json({ 
        error: 'User not found or update failed',
        message: '用户不存在或更新失败'
      });
    }

    return res.json({ 
      success: true, 
      message: `Added ${days} VIP days successfully`,
      daysAdded: days,
      recordId: result.recordId
    });
  } catch (error) {
    console.error('添加VIP天数错误:', error);
    return res.status(500).json({ 
      error: 'Internal server error',
      message: '服务器内部错误',
      detail: error.message
    });
  }
};
exports.getRechargeRecords = async (req, res) => {
  const { userId } = req.params;
  
  try {
    const records = await Vip.getRechargeRecords(userId);
    res.json(records);
  } catch (error) {
    console.error('Error fetching recharge records:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
console.log('vipController.js 已加载，导入的 Vip 模块:', Vip);