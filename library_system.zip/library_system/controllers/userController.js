const User = require('../models/userModel');

// 获取用户信息
exports.getUser = async (req, res) => {
  const { userId } = req.params;
  
  try {
    console.log(`获取用户信息: ID=${userId}`);
    const user = await User.getUserById(userId);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json({
      id: user.id,
      username: user.username,
      isVip: user.isVip,
      vipDays: user.vipDays,
      totalBorrowed: user.totalBorrowed,
      currentBorrowed: user.currentBorrowed,
      creditScore: user.creditScore,
      readingRank: user.readingRank
    });
    
  } catch (error) {
    console.error('Error fetching user:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// 获取用户借阅记录
exports.getBorrowRecords = async (req, res, userId, type) => {
  try {
    const records = await User.getBorrowRecords(userId, type);
    
    const formattedRecords = records.map(record => ({
      id: record.id,
      title: record.title,
      author: record.author,
      cover: record.cover || '📚',
      borrowDate: record.borrowDate,
      dueDate: record.dueDate,
      returnDate: record.returnDate,
      status: record.status,
      bookId: record.bookId // 添加 bookId 用于归还操作
    }));
    
    res.json(formattedRecords);
  } catch (error) {
    console.error('获取借阅记录失败:', error);
    res.status(500).json({ error: '获取借阅记录失败' });
  }
};