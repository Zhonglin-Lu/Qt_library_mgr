const Borrow = require('../models/borrowModel');
const db = require('../config/db'); // 确保引入 db 模块
const User = require('../models/userModel');
const Book = require('../models/bookModel');
// 获取推荐图书
exports.getRecommendedBooks = async (req, res) => {
  try {
    const books = await Book.getRecommendedBooks();
    res.json(books);
  } catch (error) {
    console.error('Error fetching recommended books:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// 获取热门图书
exports.getPopularBooks = async (req, res) => {
  try {
    const books = await Book.getPopularBooks();
    res.json(books);
  } catch (error) {
    console.error('Error fetching popular books:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// 获取最新图书
exports.getNewBooks = async (req, res) => {
  try {
    const books = await Book.getNewBooks();
    res.json(books);
  } catch (error) {
    console.error('Error fetching new books:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
// 获取图书详情
exports.getBookDetail = async (req, res) => {
  const { id } = req.params;
  
  try {
    const book = await Book.getBookDetail(id);
    if (!book) {
      return res.status(404).json({ error: 'Book not found' });
    }
    res.json(book);
  } catch (error) {
    console.error('Error fetching book detail:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// 搜索图书
exports.searchBooks = async (req, res) => {
  const { q } = req.query;
  
  if (!q) {
    return res.status(400).json({ error: 'Query parameter is required' });
  }
  
  try {
    const books = await Book.searchBooks(q);
    res.json(books);
  } catch (error) {
    console.error('Error searching books:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};