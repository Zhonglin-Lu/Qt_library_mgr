const Borrow = require('../models/borrowModel');
const db = require('../config/db'); 
const User = require('../models/userModel');
const Book = require('../models/bookModel');

// 更新用户信誉积分的辅助函数
async function updateCreditScore(userId, points) {
  try {
    await db.query(
      `UPDATE users 
      SET credit_score = GREATEST(300, LEAST(1000, credit_score + ?))
      WHERE id = ?`,
      [points, userId]
    );
  } catch (error) {
    console.error('更新信誉积分失败:', error);
  }
}

// 借阅图书
exports.borrowBook = async (req, res) => {
  const { userId, bookId } = req.body;
  
  if (!userId || !bookId) {
    return res.status(400).json({ error: '缺少用户ID或图书ID' });
  }
  
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    
    // 1. 检查用户
    const user = await User.getUserById(userId);
    if (!user) {
      await connection.rollback();
      return res.status(404).json({ error: '用户不存在' });
    }
    
    // 2. 检查图书
    const book = await Book.getBookById(bookId, connection);
    if (!book) {
      await connection.rollback();
      return res.status(404).json({ error: '图书不存在' });
    }
    
    // 3. 检查图书状态
    if (book.status !== 'available') {
      await connection.rollback();
      return res.status(400).json({ error: '图书已被借出' });
    }
    
    // 4. 创建借阅记录
    const borrowDate = new Date();
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + (user.isVip ? 60 : 30));
    
    const borrowRecord = await Borrow.createBorrowRecord({
      userId,
      bookId,
      borrowDate,
      dueDate
    }, connection);
    
    // 5. 更新图书状态
    await Book.updateBookStatus(bookId, 'borrowed', connection);
    
    // 6. 提交事务
    await connection.commit();
    
    // 更新信誉积分（成功借阅加分）
    await updateCreditScore(userId, 5);
    res.json({
      success: true,
      message: '借阅成功',
      recordId: borrowRecord.insertId,
      dueDate: dueDate.toISOString().split('T')[0]
    });
  } catch (error) {
    await connection.rollback();
    console.error('借阅失败:', error);
    res.status(500).json({ 
      error: '借阅失败',
      message: error.message
    });
  } finally {
    connection.release();
  }
};

// 归还图书
exports.returnBook = async (req, res) => {
  const { recordId } = req.body;
  
  if (!recordId) {
    return res.status(400).json({ 
      success: false,
      error: 'MISSING_RECORD_ID',
      message: '缺少借阅记录ID'
    });
  }
  
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    
    // 获取借阅记录并锁定
    const [record] = await connection.query(
      `SELECT * FROM borrow_records WHERE id = ? FOR UPDATE`,
      [recordId]
    );
    
    if (!record || record.length === 0) {
      await connection.rollback();
      return res.status(404).json({ 
        success: false,
        error: 'RECORD_NOT_FOUND',
        message: '借阅记录不存在'
      });
    }
    
    const borrowRecord = record[0];
    
    // 检查是否已归还
    if (borrowRecord.return_date) {
      await connection.rollback();
      return res.status(400).json({ 
        success: false,
        error: 'ALREADY_RETURNED',
        message: '该图书已归还'
      });
    }
    
    // 执行归还操作
    const returnDate = new Date();
    const returnSuccess = await Borrow.returnBook(recordId, returnDate, connection);
    
    if (!returnSuccess) {
      await connection.rollback();
      return res.status(500).json({
        success: false,
        error: 'RETURN_FAILED',
        message: '归还操作失败'
      });
    }
    
    // 更新图书状态
    const bookUpdateSuccess = await Book.updateBookStatus(
      borrowRecord.book_id, 
      'available', 
      connection
    );
    
    if (!bookUpdateSuccess) {
      await connection.rollback();
      return res.status(500).json({
        success: false,
        error: 'BOOK_STATUS_UPDATE_FAILED',
        message: '图书状态更新失败'
      });
    }
    
    // 提交事务
    await connection.commit();
    
    // 计算是否逾期
    const isOverdue = returnDate > new Date(borrowRecord.due_date);
    
    // 更新信誉积分
    if (isOverdue) {
      // 逾期归还扣分
      await updateCreditScore(borrowRecord.user_id, -10);
    } else {
      // 按时归还加分
      await updateCreditScore(borrowRecord.user_id, 3);
    }
    
    // 添加 success 字段到响应中
    res.json({
      success: true,
      message: '归还成功',
      recordId: recordId,
      bookId: borrowRecord.book_id,
      returnDate: returnDate.toISOString()
    });
  } catch (error) {
    await connection.rollback();
    console.error('归还失败:', error);
    res.status(500).json({
      success: false,
      error: 'SERVER_ERROR',
      message: '归还过程中发生错误',
      detail: error.message
    });
  } finally {
    connection.release();
  }
};

// 获取借阅记录
exports.getBorrowRecords = async (req, res) => {
  const { userId } = req.params;
  
  try {
    const records = await Borrow.getRecordsByUser(userId);
    res.json(records);
  } catch (error) {
    console.error('获取借阅记录失败:', error);
    res.status(500).json({ error: '获取借阅记录失败' });
  }
};

// 获取用户对某本书的活跃借阅记录
exports.getActiveRecord = async (req, res) => {
  const { bookId, userId } = req.query;
  
  if (!bookId || !userId) {
    return res.status(400).json({ error: '缺少图书ID或用户ID' });
  }
  
  try {
    const [record] = await db.query(
      `SELECT id FROM borrow_records 
       WHERE book_id = ? AND user_id = ? AND return_date IS NULL
       LIMIT 1`,
      [bookId, userId]
    );
    
    if (!record || record.length === 0) {
      return res.status(404).json({ error: '未找到借阅记录' });
    }
    
    res.json(record[0]);
  } catch (error) {
    console.error('获取借阅记录失败:', error);
    res.status(500).json({ error: '获取借阅记录失败' });
  }
};