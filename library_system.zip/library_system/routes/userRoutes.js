const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

// 获取用户信息
router.get('/:userId', userController.getUser);

// 获取用户借阅记录
router.get('/:userId/borrow-records', (req, res) => {
  const { userId } = req.params;
  const { type } = req.query;
  userController.getBorrowRecords(req, res, userId, type);
});

module.exports = router;