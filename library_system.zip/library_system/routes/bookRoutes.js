const express = require('express');
const router = express.Router();
const bookController = require('../controllers/bookController');

// 图书相关路由
router.get('/recommended', bookController.getRecommendedBooks);
router.get('/popular', bookController.getPopularBooks);
router.get('/new', bookController.getNewBooks);
router.get('/search', bookController.searchBooks);
router.get('/:id', bookController.getBookDetail);

module.exports = router;