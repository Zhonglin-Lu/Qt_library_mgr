const express = require('express');
const router = express.Router();
const vipController = require('../controllers/vipController');

// VIP相关路由
router.post('/:userId/recharge', vipController.addVipDays);
router.get('/:userId/recharge-records', vipController.getRechargeRecords);
module.exports = router;
console.log('vipRoutes.js 已加载，导入的 vipController:', vipController);