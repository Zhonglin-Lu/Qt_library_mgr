require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const bodyParser = require('body-parser');
const bookRoutes = require('./routes/bookRoutes');
const userRoutes = require('./routes/userRoutes');
const vipRoutes = require('./routes/vipRoutes');
const borrowRoutes = require('./routes/borrowRoutes');
const db = require('./config/db');

const app = express();
const PORT = process.env.PORT || 5000;

// 测试数据库连接
async function testDbConnection() {
  try {
    const [rows] = await db.query('SELECT 1 + 1 AS solution');
    console.log('[Database] Connection test successful:', rows[0].solution === 2);
    return true;
  } catch (err) {
    console.error('[Database] Connection failed:', err);
    return false;
  }
}

// 静态文件服务
app.use(express.static(path.join(__dirname, 'public')));

// CORS 配置
app.use(cors({
  origin: `http://localhost:${PORT}`,
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// 中间件
app.use(bodyParser.json());

// 登录路由
app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body;
  
  try {
    // 使用 SHA2 函数验证密码
    const [rows] = await db.query(
      `SELECT id, username, is_vip AS isVip, vip_days AS vipDays 
       FROM users 
       WHERE (username = ? OR email = ?) AND password = SHA2(?, 256)`,
      [username, username, password]
    );
    
    if (rows.length === 0) {
      return res.status(401).json({ 
        success: false, 
        message: '用户名或密码错误' 
      });
    }
    
    const user = rows[0];
    res.json({
      success: true,
      user: {
        id: user.id,
        username: user.username,
        isVip: user.isVip,
        vipDays: user.vipDays,
        totalBorrowed: user.totalBorrowed,
        currentBorrowed: user.currentBorrowed,
        creditScore: user.creditScore,
        readingRank: user.readingRank
      }
    });
    
  } catch (error) {
    console.error('登录失败:', error);
    res.status(500).json({ 
      success: false, 
      message: '服务器错误',
      error: error.message
    });
  }
});

// 测试路由
app.get('/api/test', (req, res) => {
  res.json({
    status: 'success',
    message: 'API is working',
    timestamp: new Date().toISOString()
  });
});

// 其他路由
app.use('/api/books', bookRoutes);
app.use('/api/users', userRoutes);
app.use('/api/vip', vipRoutes);
app.use('/api/borrow', borrowRoutes);

// 根路由重定向
app.get('/', (req, res) => {
  res.redirect('/index.html');
});

// 错误处理
app.use((err, req, res, next) => {
  console.error(err.stack);
  if (!res.headersSent) {
    res.status(500).json({ error: 'Something went wrong!' });
  }
});

// 404 处理
app.use((req, res) => {
  res.status(404).send('Page not found');
});

// 启动服务器前测试数据库连接
testDbConnection().then(success => {
  if (success) {
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Access the website at: http://localhost:${PORT}`);
    });
  } else {
    console.error('Failed to connect to database. Server not started.');
  }
});